#ifndef STATIC_HASH_H
#define STATIC_HASH_H

#include "static_hash_enum.h"

unsigned int hash_string (const char *str);

#endif // STATIC_HASH_H
