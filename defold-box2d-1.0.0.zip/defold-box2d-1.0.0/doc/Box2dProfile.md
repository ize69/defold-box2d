# Box2dProfile
Profiling data. Times are in milliseconds.
Returned by world:GetProfile().

_FIELDS_
* `step` (number) -
* `collide` (number) -
* `solve` (number) -
* `solveInit` (number) -
* `solveVelocity` (number) -
* `solvePosition` (number) -
* `broadphase` (number) -
* `solveTOI` (number) -
